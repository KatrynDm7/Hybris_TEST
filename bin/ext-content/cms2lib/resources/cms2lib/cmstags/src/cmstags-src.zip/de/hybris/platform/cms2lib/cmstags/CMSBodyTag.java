/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2015 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package de.hybris.platform.cms2lib.cmstags;

import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.cms2.model.preview.CMSPreviewTicketModel;
import de.hybris.platform.cms2.model.preview.PreviewDataModel;
import de.hybris.platform.cms2.servicelayer.services.CMSPreviewService;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.servicelayer.user.UserService;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


public class CMSBodyTag extends BodyTagSupport
{
	private static final Logger LOG = Logger.getLogger(CMSBodyTag.class);

	protected ServletContext getServletContext()
	{
		return pageContext.getServletContext();
	}

	protected boolean isLiveEdit()
	{
		return isPreviewDataModelValid() && Boolean.TRUE.equals(getPreviewData(pageContext.getRequest()).getLiveEdit());
	}

	protected boolean isPreviewDataModelValid()
	{
		return getPreviewData(pageContext.getRequest()) != null;
	}

	/**
	 * Retrieves {@link CMSFilter#PREVIEW_TICKET_ID_PARAM} from current request
	 * 
	 * @param httpRequest
	 *           current request
	 * @return current ticket id
	 */
	protected String getPreviewTicketId(final ServletRequest httpRequest)
	{
		String id = httpRequest.getParameter(CMSFilter.PREVIEW_TICKET_ID_PARAM);
		final WebApplicationContext appContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
		final SessionService sessionService = (SessionService) appContext.getBean("sessionService");
		if (StringUtils.isBlank(id))
		{
			id = sessionService.getAttribute(CMSFilter.PREVIEW_TICKET_ID_PARAM);
		}
		return id;
	}

	/**
	 * Checks whether current Preview Data is valid (not removed)
	 * 
	 * @param httpRequest
	 *           current request
	 * @return true whether is valid otherwise false
	 */
	protected PreviewDataModel getPreviewData(final ServletRequest httpRequest)
	{
		return getPreviewData(getPreviewTicketId(httpRequest), httpRequest);
	}

	/**
	 * Retrieves current Preview Data according to given ticked id
	 * 
	 * @param ticketId
	 *           current ticket id
	 * @param httpRequest
	 *           current request
	 * @return current Preview Data attached to given ticket if any otherwise null
	 */
	protected PreviewDataModel getPreviewData(final String ticketId, final ServletRequest httpRequest)
	{
		PreviewDataModel ret = null;
		final WebApplicationContext appContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
		final CMSPreviewService cmsPreviewService = (CMSPreviewService) appContext.getBean("cmsPreviewService");
		final CMSPreviewTicketModel previewTicket = cmsPreviewService.getPreviewTicket(ticketId);
		if (previewTicket != null)
		{
			ret = previewTicket.getPreviewData();
		}
		return ret;
	}


	@Override
	public int doStartTag() throws JspException
	{
		/*
		 * Use for CMSCockpit integration - please provide here some logic that informs CMSCockpit about store specific
		 * information.
		 */
		final String extraScript = "<script type=\"text/javascript\">\n" + " var currentUserId;\n" + " var currentJaloSessionId;\n"

		+ " function getCurrentPageLocation(url, pagePk, userUid, jaloSessionId){\n" + "   if (url != \"\") {\n"
				+ "       	parent.postMessage({eventName:notifyIframeAboutUrlChange, data: [url, pagePk, userUid, jaloSessionId]},'*');\n" + " 	  	\n" + "   }\n"
				+ "}\n" + "</script>\n";

		final AbstractPageModel currentPage = (AbstractPageModel) pageContext.getRequest().getAttribute("currentPage");
		String currentPagePk = null;
		if (currentPage != null)
		{
			currentPagePk = currentPage.getPk().toString();
		}
		final StringBuilder bodyTagBuilder = new StringBuilder();
		bodyTagBuilder.append("body");
		bodyTagBuilder.append(isPreviewDataModelValid() ? " onload=\"getCurrentPageLocation(window.location.href, '"
				+ currentPagePk + "' , currentUserId " + ", currentJaloSessionId)\"" : "");
		bodyTagBuilder.append(isLiveEdit() ? " onclick=\"return getCMSElement(event)\"" : "");
		try
		{
			pageContext.getOut().print("<" + bodyTagBuilder.toString() + ">\n");
			pageContext.getOut().print(isPreviewDataModelValid() ? extraScript : "");
		}
		catch (final IOException e)
		{
			LOG.warn("Error processing tag: " + e.getMessage());
		}
		return EVAL_BODY_INCLUDE;
	}

	@Override
	public int doAfterBody() throws JspException
	{
		try
		{
			final StringBuilder bodyTagBuilder = new StringBuilder();

			bodyTagBuilder.append(isPreviewDataModelValid() ? "<script>currentUserId='" + getCurrentUserUid()
					+ "';currentJaloSessionId='" + getCurrentJaloSessionId() + "';</script>" : "");
			bodyTagBuilder.append("</body>");
			pageContext.getOut().print(bodyTagBuilder.toString());
		}
		catch (final IOException e)
		{
			LOG.warn("Error processing tag: " + e.getMessage());
		}
		return SKIP_BODY;
	}

	protected String getCurrentUserUid()
	{
		String ret = StringUtils.EMPTY;
		final WebApplicationContext appContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
		final UserService userService = (UserService) appContext.getBean("userService");
		if (userService != null)
		{
			ret = userService.getCurrentUser().getUid();
		}
		return ret;
	}

	protected String getCurrentJaloSessionId()
	{
		String ret = StringUtils.EMPTY;
		final WebApplicationContext appContext = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
		final SessionService sessionService = (SessionService) appContext.getBean("sessionService");
		if (sessionService != null)
		{
			ret = sessionService.getCurrentSession().getSessionId();
		}
		return ret;
	}

}
